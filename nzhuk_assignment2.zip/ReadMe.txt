Evaluation Function:
Count the amount of empty spaces on the board
------------------------------------------------

Board Size: 6x6
AI player is: 1
Minimax
Nodes expanded: 478670
Depth Level: 3
----------------
Board Size: 6x6
AI player is: 2
Minimax
Nodes expanded: 1300116
Depth Level: 4
----------------
Board Size: 6x6
AI player is: 1
Minimax with AB pruning
Nodes expanded: 78190
Depth Level: 3
----------------
Board Size: 6x6
AI player is: 2
Minimax with AB pruning
Nodes expanded: 56879
Depth Level: 4
----------------
Board Size: 6x7
AI player is: 1
Minimax
Nodes expanded: 1126951
Depth Level: 3
----------------
Board Size: 6x7
AI player is: 2
Minimax
Nodes expanded: 4750845
Depth Level: 4
----------------
Board Size: 6x7
AI player is: 1
Minimax with AB pruning
Nodes expanded: 118229
Depth Level: 3
----------------
Board Size: 6x7
AI player is: 2
Minimax with AB pruning
Nodes expanded: 101419
Depth Level: 4
----------------
Board Size: 7x8
AI player is: 1
Minimax with AB pruning
Nodes expanded: 411284
Depth Level: 3
----------------
Board Size: 7x8
AI player is: 1
Minimax with AB pruning
Nodes expanded: 2462113
Depth Level: 4
----------------
Board Size: 8x8
AI player is: 1
Minimax with AB pruning
Nodes expanded: 732968
Depth Level: 3
----------------
Board Size: 8x8
AI player is: 1
Minimax with AB pruning
Nodes expanded: 4639619
Depth Level: 4
----------------